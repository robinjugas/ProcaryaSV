../../bin/lumpy -P \
-msw 4 \
-tt 0 \
-sr bam_file:test.filtered_split.bam,back_distance:10,min_mapping_threshold:20,weight:1,id:test,min_clip:20 
