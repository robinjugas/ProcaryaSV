    samtools view \
        -o NA12878.bam \
        -b \
        ftp://ftp-trace.ncbi.nih.gov/1000genomes/ftp/phase3/data/NA12878/high_coverage_alignment/NA12878.mapped.ILLUMINA.bwa.CEU.high_coverage_pcr_free.20130906.bam \
        7:71000000-72000000

    samtools view \
        -o NA12891.bam \
        -b \
        ftp://ftp-trace.ncbi.nih.gov/1000genomes/ftp/phase3/data/NA12891/high_coverage_alignment/NA12891.mapped.ILLUMINA.bwa.CEU.high_coverage_pcr_free.20130906.bam \
        7:71000000-72000000


    samtools view \
        -o NA12892.bam \
        -b \
        ftp://ftp-trace.ncbi.nih.gov/1000genomes/ftp/phase3/data/NA12892/high_coverage_alignment/NA12892.mapped.ILLUMINA.bwa.CEU.high_coverage_pcr_free.20130906.bam \
        7:71000000-72000000


