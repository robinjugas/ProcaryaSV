#ifndef VERSION_GIT_H
#define VERSION_GIT_H
#define VERSION_GIT "v2.16.2-20-gbe83482-dirty"
#endif /* VERSION_GIT_H */
